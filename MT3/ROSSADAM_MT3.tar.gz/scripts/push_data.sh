#!/bin/bash

cp /oasis/scratch/comet/adamross/temp_project/* dev/data/. && git add dev/data/* && git commit -m 'new data' && git push