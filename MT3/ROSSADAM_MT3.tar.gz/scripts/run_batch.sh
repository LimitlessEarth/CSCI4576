#!/bin/bash

sbatch batch_files/RossAdam_MT3.sh

